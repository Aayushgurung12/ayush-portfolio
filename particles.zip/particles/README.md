# Particles

A Pen created on CodePen.

Original URL: [https://codepen.io/StarKnightt/pen/GggPqLM](https://codepen.io/StarKnightt/pen/GggPqLM).

It is a sophisticated interactive particle animation system that creates a mesmerizing cosmic visualization. 