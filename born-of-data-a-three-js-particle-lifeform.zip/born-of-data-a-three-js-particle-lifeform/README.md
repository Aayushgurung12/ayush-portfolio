# Born of Data – A Three.js Particle Lifeform

A Pen created on CodePen.

Original URL: [https://codepen.io/VoXelo/pen/VYexvqY](https://codepen.io/VoXelo/pen/VYexvqY).

Built with Three.js and glsl shaders, this interactive particle animation creates glowing formations that shift between a sphere, vortex, and nebula. Users can toggle trails, glow, and color from a cybernetic control panel.