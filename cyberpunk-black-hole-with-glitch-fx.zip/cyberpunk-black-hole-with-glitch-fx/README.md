# Cyberpunk Black Hole with Glitch FX

A Pen created on CodePen.

Original URL: [https://codepen.io/VoXelo/pen/QwjvyQK](https://codepen.io/VoXelo/pen/QwjvyQK).

Immersive 3D black hole scene built with Three.js, GLSL shaders, and WebGL. Real-time camera dynamics, animated starfields, chromatic lensing, and glitch-triggered distortions blend into a rich cyberpunk aesthetic.