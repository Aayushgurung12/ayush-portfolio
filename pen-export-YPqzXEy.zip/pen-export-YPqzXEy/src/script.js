/* 
  the hypotrochoid ball thing at:
  https://www.mathcurve.com/courbes3d.gb/couture/couture.shtml
*/